#pragma once

#define MAX_CHARS 100
#define MAX_CHARS_LINE 1024
#define DEBUG 1
#define DEBUG_TIME 1
#define DEBUG_TREE 0
#define PRINT_CSV 1